// JavaScript for form handling
document.getElementById('feedbackForm').addEventListener('submit', function (event) {
    event.preventDefault();

    // Get form data and handle backend operations (e.g., send to server)
    // You may use fetch() or another AJAX method for this
    // Example:
    // const formData = new FormData(event.target);
    // fetch('/submit-feedback', {
    //     method: 'POST',
    //     body: formData
    // })
    // .then(response => response.json())
    // .then(data => console.log(data))
    // .catch(error => console.error('Error:', error));
});
